package com.brainmentors.users.db;

public class UserDB {
    
}
