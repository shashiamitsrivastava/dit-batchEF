package com.brainmentors.users.views;

import com.brainmentors.courses.views.CourseView;

class UserView{
    private String userid; // with in the class
    void login(){
        // After Login
        CourseView courseView = new CourseView();
        courseView.mbaCourse();
    }
    void register(){

    }
    public static void main(String[] args) {
        int x = 10; // Local Variable
    }
}