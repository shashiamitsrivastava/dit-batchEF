package com.brainmentors.courses.views;

public class CourseView {
    // default scope - with in the package
    void itCourses(){
        System.out.println("IT Courses");
    }
    
    public void mbaCourse(){
        System.out.println("MBA Courses");
    }
    
}
