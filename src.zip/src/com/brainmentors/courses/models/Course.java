package com.brainmentors.courses.models;

public class Course {
    protected int id; // default
    protected String name;
    protected double fees;
}
