package com.brainmentors.courses.db;

public class CourseDB {
    
}
