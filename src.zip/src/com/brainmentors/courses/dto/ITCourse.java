package com.brainmentors.courses.dto;

import com.brainmentors.courses.models.Course;

class MedCourse {
    Course course = new Course();
    void show(){
         int x;
    }
}
public class ITCourse extends Course {

    public ITCourse(){
        id = 1001;
        name = "IT Course";
        fees = 10000;
    }
    private class A{

    }
}
