abstract class Employee{
    int id;
    String name;
    double salary;
    void salaryCompute(){

    }
    void bonus(){

    }
    abstract void joinForm(); // Method Declare (What to do)

    
    
}
 class FullTimeEmployee extends Employee{
    void addAllowances(){
        
    }
    void joinForm(){

    }
}
class PartTimeEmployee extends Employee{
    void flexiTime(){

    }
    void noPF(){

    }
    void joinForm(){
        
    }
}
public class AbstractClassDemo {
    public static void main(String[] args) {
        //Employee tim =new Employee();
        FullTimeEmployee ram = new FullTimeEmployee();
        PartTimeEmployee shyam = new PartTimeEmployee();
    }
}
