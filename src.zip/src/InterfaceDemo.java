// interface
// what to do - Plan (Standard)
// interface 100% abstract
// interface = Abstract methods + Constants
interface Player{
    int MAX = 100; // public static final int MAX =100
    void jump(); //public abstract void jump();
    void run();
    void punch();
    void walk(); 
}
interface ExtraPower{
    void extra();
    void limitedTime();
}
interface Hybrid extends Player, ExtraPower{

}
class CommonPlayer{

}
// class - how to do
class Ryu extends CommonPlayer implements Player, ExtraPower{

    @Override
    public void jump() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'jump'");
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

    @Override
    public void punch() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'punch'");
    }

    @Override
    public void walk() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'walk'");
    }

}
class Honda implements Hybrid{

    @Override
    public void jump() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'jump'");
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'run'");
    }

    @Override
    public void punch() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'punch'");
    }

    @Override
    public void walk() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'walk'");
    }

    @Override
    public void extra() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'extra'");
    }

    @Override
    public void limitedTime() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'limitedTime'");
    }

}
class Ken{

}
public class InterfaceDemo {
    public static void main(String[] args) {
        
    }
}
